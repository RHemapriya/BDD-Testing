$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/heravich/Desktop/Spring BDD Test/Module4Registration/src/test/resources/RegistrationFeature/Registration.feature");
formatter.feature({
  "line": 1,
  "name": "Testing for registration Form",
  "description": "",
  "id": "testing-for-registration-form",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Checking title",
  "description": "",
  "id": "testing-for-registration-form;checking-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "user enters the html page",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "displays \u0027Welcome to JobsWorld\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "RegistrationstepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 2457857400,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.user_enters_the_html_page()"
});
formatter.result({
  "duration": 23100,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.displays_Welcome_to_JobsWorld()"
});
formatter.result({
  "duration": 13062800,
  "error_message": "org.junit.ComparisonFailure: expected:\u003c[Welcome to JobsWorld]\u003e but was:\u003c[]\u003e\r\n\tat org.junit.Assert.assertEquals(Assert.java:115)\r\n\tat org.junit.Assert.assertEquals(Assert.java:144)\r\n\tat RegistrationStepDefinition.RegistrationstepDefinition.displays_Welcome_to_JobsWorld(RegistrationstepDefinition.java:35)\r\n\tat ✽.Then displays \u0027Welcome to JobsWorld\u0027(C:/Users/heravich/Desktop/Spring BDD Test/Module4Registration/src/test/resources/RegistrationFeature/Registration.feature:6)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 8,
  "name": "Invalid UserId",
  "description": "",
  "id": "testing-for-registration-form;invalid-userid",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "user enters Invalid id",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "displays \u0027User Id should not be empty / length be between 5 to 12\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "RegistrationstepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 4421196900,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.user_enters_Invalid_id()"
});
formatter.result({
  "duration": 2193168300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5",
      "offset": 58
    },
    {
      "val": "12",
      "offset": 63
    }
  ],
  "location": "RegistrationstepDefinition.displays_User_Id_should_not_be_empty_length_be_between_to(int,int)"
});
formatter.result({
  "duration": 4338503600,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "Invalid Password Field",
  "description": "",
  "id": "testing-for-registration-form;invalid-password-field",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 14,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "user enters invalid password",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "display \u0027Password should not be empty / length be between 7 to 12\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "RegistrationstepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 3024475800,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.user_enters_invalid_password()"
});
formatter.result({
  "duration": 2260251600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "7",
      "offset": 58
    },
    {
      "val": "12",
      "offset": 63
    }
  ],
  "location": "RegistrationstepDefinition.display_Password_should_not_be_empty_length_be_between_to(int,int)"
});
formatter.result({
  "duration": 4352048200,
  "status": "passed"
});
formatter.scenario({
  "line": 19,
  "name": "Invalid Name",
  "description": "",
  "id": "testing-for-registration-form;invalid-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 20,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 21,
  "name": "user enters invalid name",
  "keyword": "When "
});
formatter.step({
  "line": 22,
  "name": "display \u0027Name should not be empty and must have alphabet characters only\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "RegistrationstepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 4051806400,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.user_enters_invalid_name()"
});
formatter.result({
  "duration": 2356230600,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.display_Name_should_not_be_empty_and_must_have_alphabet_characters_only()"
});
formatter.result({
  "duration": 4474771600,
  "status": "passed"
});
formatter.scenario({
  "line": 24,
  "name": "Invalid address",
  "description": "",
  "id": "testing-for-registration-form;invalid-address",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 25,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 26,
  "name": "user enters invalid address",
  "keyword": "When "
});
formatter.step({
  "line": 27,
  "name": "display \u0027User address must have alphanumeric characters only\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "RegistrationstepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 4869165900,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.user_enters_invalid_address()"
});
formatter.result({
  "duration": 2658003800,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.display_User_address_must_have_alphanumeric_characters_only()"
});
formatter.result({
  "duration": 4400394100,
  "status": "passed"
});
formatter.scenario({
  "line": 29,
  "name": "Invalid country",
  "description": "",
  "id": "testing-for-registration-form;invalid-country",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 30,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 31,
  "name": "user enters invalid country",
  "keyword": "When "
});
formatter.step({
  "line": 32,
  "name": "display \u0027Select your country from the list\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "RegistrationstepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 5589047500,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.user_enters_invalid_country()"
});
formatter.result({
  "duration": 2529484000,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.display_Select_your_country_from_the_list()"
});
formatter.result({
  "duration": 4341558700,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "Invalid Zip code",
  "description": "",
  "id": "testing-for-registration-form;invalid-zip-code",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 36,
  "name": "user enters invalid zip code",
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "display \u0027ZIP code must have numeric characters only\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "RegistrationstepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 3824925400,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.user_enters_invalid_zip_code()"
});
formatter.result({
  "duration": 2910018100,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.display_ZIP_code_must_have_numeric_characters_only()"
});
formatter.result({
  "duration": 4225484800,
  "status": "passed"
});
formatter.scenario({
  "line": 39,
  "name": "Invalid Email",
  "description": "",
  "id": "testing-for-registration-form;invalid-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 40,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 41,
  "name": "user enters invalid ename",
  "keyword": "When "
});
formatter.step({
  "line": 42,
  "name": "displays \u0027You have entered an invalid email address!\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "RegistrationstepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 3806744700,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.user_enters_invalid_ename()"
});
formatter.result({
  "duration": 2726427100,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.displays_You_have_entered_an_invalid_email_address()"
});
formatter.result({
  "duration": 4611919100,
  "status": "passed"
});
formatter.scenario({
  "line": 44,
  "name": "Invalid gender",
  "description": "",
  "id": "testing-for-registration-form;invalid-gender",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 45,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 46,
  "name": "user doesnot select gender",
  "keyword": "When "
});
formatter.step({
  "line": 47,
  "name": "displays \u0027Please Select gender\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "RegistrationstepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 1788647500,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.user_doesnot_select_gender()"
});
formatter.result({
  "duration": 703206500,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.displays_Please_Select_gender()"
});
formatter.result({
  "duration": 2567600300,
  "status": "passed"
});
formatter.scenario({
  "line": 49,
  "name": "Valid Registration details",
  "description": "",
  "id": "testing-for-registration-form;valid-registration-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 50,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 51,
  "name": "user enters valid  registration details",
  "keyword": "When "
});
formatter.step({
  "line": 52,
  "name": "displays \u0027Registartion completed\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "RegistrationstepDefinition.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 2108272900,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.user_enters_valid_registration_details()"
});
formatter.result({
  "duration": 868592600,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationstepDefinition.displays_Registartion_completed()"
});
formatter.result({
  "duration": 2422596800,
  "status": "passed"
});
});