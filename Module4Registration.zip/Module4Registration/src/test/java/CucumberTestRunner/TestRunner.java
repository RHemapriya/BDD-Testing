package CucumberTestRunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
       features = "C:\\Users\\heravich\\Desktop\\Spring BDD Test\\Module4Registration\\src\\test\\resources\\RegistrationFeature\\Registration.feature",
       glue= {"RegistrationStepDefinition"},
       monochrome=false,
    		   format= {"pretty" , "html:registration1-output"}
       )
public class TestRunner {

}
