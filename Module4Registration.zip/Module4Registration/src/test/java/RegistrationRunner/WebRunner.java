package RegistrationRunner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebRunner {
	public static WebDriver getWebDriver() {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\heravich\\Desktop\\chromedriver\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		return driver;

	}
}
