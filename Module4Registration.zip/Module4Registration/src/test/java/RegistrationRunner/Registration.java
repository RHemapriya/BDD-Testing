package RegistrationRunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "C:\\Users\\heravich\\Desktop\\Spring BDD Test\\Module4Registration\\src\\test\\resources\\RegistrationFeature\\Registration.feature",
format= {"pretty" , "html:registration-output"})
public class Registration {
	public static void main(String[] args) {

	}

}
