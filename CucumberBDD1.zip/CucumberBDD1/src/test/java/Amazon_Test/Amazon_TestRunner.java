package Amazon_Test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
        features= {"C:\\Users\\heravich\\Desktop\\Spring BDD Test\\CucumberBDD1\\src\\test\\resource\\Features\\Amazon.feature"},
        glue= {"Amazon_Test"},
        dryRun=false,
        strict=true,
        monochrome=true,
        format= {"pretty" , "html:amazon-output"}
        )

 


public class Amazon_TestRunner {
    
}