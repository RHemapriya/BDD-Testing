$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/heravich/Desktop/Spring BDD Test/CucumberBDD1/src/test/resource/Features/Amazon.feature");
formatter.feature({
  "line": 1,
  "name": "validating the amazon size",
  "description": "",
  "id": "validating-the-amazon-size",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Search an item and get the title",
  "description": "",
  "id": "validating-the-amazon-size;search-an-item-and-get-the-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "the user is on the amazon home page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "select the category as Books",
  "keyword": "Then "
});
formatter.step({
  "line": 6,
  "name": "the user should enter Da vinci code in the search textbox",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "the user should click on magnifier button",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "get the title of the books and print",
  "keyword": "Then "
});
formatter.match({
  "location": "SearchItem_StepDefinition.the_user_is_on_the_amazon_home_page()"
});
formatter.result({
  "duration": 34097773700,
  "status": "passed"
});
formatter.match({
  "location": "SearchItem_StepDefinition.select_the_category_as_Books()"
});
formatter.result({
  "duration": 891250000,
  "status": "passed"
});
formatter.match({
  "location": "SearchItem_StepDefinition.the_user_should_enter_Da_vinci_code_in_the_search_textbox()"
});
formatter.result({
  "duration": 263398000,
  "status": "passed"
});
formatter.match({
  "location": "SearchItem_StepDefinition.the_user_should_click_on_magnifier_button()"
});
formatter.result({
  "duration": 12111417300,
  "status": "passed"
});
formatter.match({
  "location": "SearchItem_StepDefinition.get_the_title_of_the_books_and_print()"
});
formatter.result({
  "duration": 2508467700,
  "status": "passed"
});
});