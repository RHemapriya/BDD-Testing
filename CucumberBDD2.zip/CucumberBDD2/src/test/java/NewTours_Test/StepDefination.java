package NewTours_Test;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import bean.factory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination {
	
	WebDriver driver;
	factory fac;
	
	
	
	@Given("^user is on 'hotelBooking' page$")
	public void user_is_on_hotelBooking_page() {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\heravich\\Desktop\\chromedriver\\chromedriver.exe");
	        driver = new ChromeDriver();
	        driver.get("C:\\Users\\heravich\\Desktop\\Spring BDD Test\\ModelExamBDD\\hotelbooking.html");
	        fac= new factory(driver);
		
	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws InterruptedException {
		Thread.sleep(5000);
		fac.setFirstName("");
		fac.setConfirmButton();
		
		
		
	}

	@Then("^displays 'Please fill the first Name'$")
	public void displays_Please_fill_the_first_Name() throws InterruptedException {
		Thread.sleep(5000);
		String expectedMessage="Please fill the First Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
		
		
	}

}
