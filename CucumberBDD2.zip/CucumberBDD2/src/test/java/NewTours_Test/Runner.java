package NewTours_Test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"C:\\Users\\heravich\\Desktop\\Spring BDD Test\\CucumberBDD2\\src\\test\\resources\\Feature\\NewTours.feature"},
		glue= {"NewTours_Test"},
		dryRun=false,
		monochrome=true,
		strict=true
		
		)
public class Runner {

}
